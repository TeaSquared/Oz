# Scoprio
Scorpio robot work for LRC

  Goals:
  
    1. Finish any remaining percent things 
    2. Make a working walking gate
    3. Make a working strage gate
    4. Integrate arrow keys
